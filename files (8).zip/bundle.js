// Tek dosyalık sürüm üretir (HTML+CSS+JS içeride). Kullanım: node scripts/bundle.js [--out=dist/kart-masasi.html] [--claude]
// --claude: claude.ai "room" yeteneğini de dener (yalnızca claude.ai artifact'ı için; bağımsız sürümde gerekmez).
const fs=require("fs"),path=require("path"),root=path.join(__dirname,".."),arg=k=>(process.argv.find(a=>a.startsWith("--"+k+"="))||"").split("=")[1];
let h=fs.readFileSync(path.join(root,"index.html"),"utf8"),js=fs.readFileSync(path.join(root,"game.js"),"utf8");const css=fs.readFileSync(path.join(root,"style.css"),"utf8");
if(process.argv.includes("--claude"))js=js.replace("async function roomApi(){\n","async function roomApi(){\n try{if(window.claude&&window.claude.use){const r=await window.claude.use(\"room\");if(r)return r}}catch(e){}\n");
const fb=(u)=>`<script>window.THREE||document.write('<script src="${u}"><\\/script>')</script>`;
let three='<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>\n'+fb("https://cdn.jsdelivr.net/npm/three@0.128.0/build/three.min.js")+"\n"+fb("https://unpkg.com/three@0.128.0/build/three.min.js");const v=path.join(root,"vendor","three.min.js");if(process.argv.includes("--offline")){if(!fs.existsSync(v))throw new Error("vendor/three.min.js yok");three="<script>\n"+fs.readFileSync(v,"utf8").replace(/<\/script/g,"<\\/script")+"\n</script>\n<script>if(!window.THREE){document.body.innerHTML='<div style=\"position:fixed;inset:0;display:flex;align-items:center;justify-content:center;color:#fff;background:#1a1420;font:16px system-ui;padding:20px;text-align:center\">three.js yüklenemedi.</div>'}</script>"}
const OFFTXT=process.argv.includes("--offline")?"İnternet GEREKMEZ: three.js (r128, MIT) bu dosyanın içine gömülüdür; oyun çevrimdışı açılır.":"İnternet gerekir: three.js CDN'den yüklenir (cdnjs, olmazsa jsDelivr, olmazsa unpkg).";
const HEADER=`<!--
KART MASASI 3D: TEK DOSYA (HTML + CSS + JS içinde). MIT lisansı.

NE: three.js (r128) ile yazılmış 3D, sıra tabanlı, gizli talimatlı blöf kart oyunu. 2-4 kişilik; boş koltuklara bot oturur.
Çevrimdışı (botlarla) ve online (arkadaşlarla) oynanır. Telefon/bilgisayar modu ilk ekranda sorulur. Arayüz Türkçe.

ÇALIŞTIRMA: Bu dosyayı .html olarak kaydedip tarayıcıda aç ya da herhangi bir statik yere index.html diye yükle (Vercel, GitHub Pages, Netlify...).
${OFFTXT} Online mod herkese açık MQTT aracılarını (WebSocket) kullanır;
sunucu ya da hesap gerekmez. Başka dosya gerekmez.

KURALLAR: Herkes 2 kartla başlar, kalanlar destede. Sıra gelince karta tıkla = ortaya koy, PAS = sırayı geç; istersen tur başına bir kez desteden kart çek
(Al / Ortaya at: ilk kapan alır / Geri koy). Ortada en az 3 kart varken herkes üst üste pas derse oyun biter. Gizli talimatlar:
  Üçlü bonus: 3 kart da ortadaysa herkes +10, değilse herkes -3.   Hain (1 kişi): aynı üçlü tamamlanırsa -15, tamamlanmazsa +10.
  İkili ceza: X ve Y birlikte ortadaysa X'i koyan -10, değilse X'in sahibi +3.   Yalan ödülü: Y kartını başkası koyarsa +8, koymazsa -2.
  Gizli ittifak (3-4 kişi): iki ortağın toplamı diğerlerinin toplamından yüksekse ikisi de +10, değilse -3.   Sabotaj Tozu: kapalı konursa üçlü bonus iptal olur.

KOD HARİTASI (<script> içinde, yaklaşık yukarıdan aşağı):
  sahne: renderer, scene, cam, fit, mk, sprite, faceTex/backTex/shadowTex, cardMesh, showMid/hideMid
  arayüz: R (kural metinleri), say, bubble, hud, deckUI, layout (elim), layoutRow (masadaki sıra), drawRP (parşömen dokusu)
  cihaz + parşömen: setDev, updAct, handMesh, parchTick (bant sökme / el animasyonu), openBig/closeBig, askExit/doExit
  online: clean/esc, relayApi, mqttApi (mqttOpen = kendi küçük MQTT 3.1.1 istemcisi), roomApi, onlineMenu/createRoom/joinRoom, netPeers,
          startOnline, remote, rejoin, sync (host), clientSetup/applyView/feeds (istemci)
  kurulum: buildScene, setup(n, opts: dağıtım, hain, ittifak, talimatlar)
  botlar: claim (doğru/yalan beyan), val, thr, botTurn, sabReact
  tur akışı: next, cont, draw, take, decide, grab, dealDeck, act, finish (puanlama)
  tıklama/klavye/döngü: pointerdown/pointermove/keydown, loop
  Ana durum nesnesi: G (items, holder, thrown, pot, deck, rules, tr=hain, tri=üçlü, cur, my, card, mid...). Zamanlayıcılar later() ile kurulur.

TASARIM KARARLARI (değiştirmeden önce düşün):
  Oyun çıkmaza girmemeli: her talimatın iki sonucu var, ortada en az 3 kart gerekir, herkes pas derse destede kalanlar dağıtılır.
  Sıra PAS'a kadar değişmez. Kart çekmek/almak/ortaya atmak zorunlu değil. Talimatlar gizli; botlar başta talimatlarını doğru ya da yalan açıklar.
  Online: host yetkili (oyun mantığı oda sahibinin tarayıcısında). Taşıma katmanı: join(oda) -> {presence(patch), peers(), onPeers(fn), leave()}.
  presence anahtarları [A-Za-z_][A-Za-z0-9_-]* olmalı, oyuncuya özel veriler DİZİ içinde, metinler clean() ile temiz. Peer kimliği p.peer===NET.me ile karşılaştırılır.
  Deste yüzü aşağı kart destesidir; kart çekilince üstteki kartın alt ucu hafifçe kıvrılır (kart belli olmaz). Ortaya atılan kart havada durmaz: masanın önüne, dizilen kartlardan ayrı bir yere düz konur (parlayan çerçeve = kapılabilir). Talimat parşömeni tahta duvara bantlıdır; tıklayınca eller bantı sökerek getirir (havada durmaz). Çıkış her zaman onay ister.
BİLİNEN EKSİKLER: 3D yerleşim ve dokunmatik kontroller gerçek cihazlarda az denendi. presence herkese açıktır (başkasının eli teknik olarak okunabilir).
Bot sohbeti hazır cümlelerden. Ses yok. Tam proje (sunucu, testler): TUM-KODLAR.txt.
-->
`;
const step=(a,b)=>{if(!h.includes(a))throw new Error("bundle: bulunamadı: "+a.slice(0,50));h=h.replace(a,()=>b)};
step('<link rel="manifest" href="manifest.webmanifest">','');h=h.replace('<link rel="apple-touch-icon" href="icons/icon-192.png">','');js=js.replace(/\ntry\{if\(typeof navigator[^\n]*\n/,"\n");step('<link rel="stylesheet" href="style.css">',"<style>\n"+css+"</style>");step('<script src="config.js"></script>\n','');
h=h.replace(/<script src="vendor\/three\.min\.js"><\/script>\n(?:<script>window\.THREE[^\n]*<\/script>\n){1,3}/,()=>three+"\n");
step('<script src="game.js"></script>',"<script>\n"+js.replace(/<\/script/g,"<\\/script")+"</script>");
h=h.replace("<!DOCTYPE html>\n",()=>"<!DOCTYPE html>\n"+HEADER);
const out=path.resolve(root,arg("out")||"dist/kart-masasi.html");fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,h);console.log("yazıldı:",out,(h.length/1024).toFixed(0)+" KB");
